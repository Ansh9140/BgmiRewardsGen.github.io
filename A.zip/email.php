<?php
$emailku = 'player5993op@gmail.com'; // GANTI EMAIL KAMU DISINI
?>